projdir <- "~/IATTC/2019_CPUE/"
jpdir <- paste0(projdir, "JP/")
datadir_orig <- paste0(jpdir, "Japan/Operational Level Data/20190126/CE/")
datadir1 <- paste0(jpdir, "data/")
jalysis_dir <- paste0(jpdir, "analyses/")
jpfigs <- paste0(jpdir, "figures/")
Rdir <- paste0(projdir, "Rfiles/")

dir.create(jpdir)
dir.create(datadir1)
dir.create(jalysis_dir)
dir.create(jpfigs)

setwd(jalysis_dir)

options(max.print = 5000)

library(stringi)
library(htmlwidgets)
library("date")
library("splines")
library("maps")
library("mapdata")
library("maptools")
library("data.table")
library("lunar")
library("lubridate")
library("readr")
library("plyr")
library("dplyr")
library("dtplyr")
library("tm")
library("colorspace")
library("tidyverse")

#install.packages("devtools")
library(devtools)
# This new library replaces the 'support functions.r' file.
#install_github("hoyles/cpue.rfmo")

library("cpue.rfmo")

#source(paste0(Rdir,"support_functions.r"))
#xsd # stop!



# ===================================================================================
# Please keep the data format consistent between years and for the IATTC + IOTC analyses.
# wdths <- c(4,2,2,2,1,3,1,6,3,6,3,3,3,3,3,3,3,3,3,8,3,4,3,30,9)
# cc <- "iiiiiiiciiiiiiiiiiiiiicci"
# posses <- cumsum(c(1,wdths))
# cc <- "iiiiiiiciiiiiiiiiiiiiicci"
# cbind(nms,wdths,unlist(strsplit(cc,"")))

# the following two lines can be used to check the data format.
# chk <- readLines(paste0(datadir1,"/JPNLL_20170524.dat"))
# chk[10240:10242]

# Check the first 20 rows
# a <- data.frame(read_fwf(file = paste0(datadir1,"/JPNLL_AO_20180417.dat"),fwf_widths(wdths),col_types = cc,n_max = 20));gc()
# cbind(names(a), nms)
# names(a) <- nms
# a

# a <- read_csv(paste0(datadir_orig,"CE_PTS_20190122_Pac.csv"))
# prepdat <- as.data.frame(a)
# names(prepdat)
# nms <- c("ocean","op_yr","op_mon","op_day","lat","latcode","lon","loncode","callsign","vesstyp","target","mainline","branchline",
#          "hbf","lbranch","lfloat","hooks","setnum","logbookid","alb","bet","yft","swo","mls","bum","blm","sas","sha","sai","spf",
#          "PTS95","PTS85","PTS75","PTS65","PTS50","Fune","Log_CE","CAL_CE","tonnage",
# rbind(names(prepdat), nms)

# January 25-29, 2019, adapted from Cleridy's notes
load(paste0(datadir_orig,"CE_20190126.RData"))
rm(a,aa,b,bb,c,cc,d,dd,e,ee,f,ff,g,gg,h,hh,i,ii,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z)

windows(width = 15,height = 9)
hist(comp.d$YY,breaks = 1950:2020, main = "Sets per year", xlab = "Year")
savePlot(filename = "sets_per_year.png",type = "png")

# # Data cleaning for JPN C&E LL data
# # coerce "." to NA in numeric fields
# comp.d$latitude<-as.numeric(as.character(comp.d$latitude))
# comp.d$vessel_type<-as.numeric(as.character(comp.d$vessel_type))
# comp.d$gear<-as.numeric(as.character(comp.d$gear))
# comp.d$MAIN<-as.numeric(as.character(comp.d$MAIN))
# comp.d$Branch<-as.numeric(as.character(comp.d$Branch))
# comp.d$NHBF<-as.numeric(as.character(comp.d$NHBF))
# comp.d$LBranch<-as.numeric(as.character(comp.d$LBranch))
# comp.d$Lfloat<-as.numeric(as.character(comp.d$Lfloat))
# comp.d$HOOK<-as.numeric(as.character(comp.d$HOOK))
# comp.d$PTS95<-as.numeric(as.character(comp.d$PTS95))
# comp.d$PTS85<-as.numeric(as.character(comp.d$PTS85))
# comp.d$PTS75<-as.numeric(as.character(comp.d$PTS75))
# comp.d$PTS65<-as.numeric(as.character(comp.d$PTS65))
# comp.d$PTS50<-as.numeric(as.character(comp.d$PTS50))

# remove records with missing data for latitude, longitude and hooks
#comp.d<-comp.d[!is.na(comp.d$latitude) & !is.na(comp.d$HOOK) & !is.na(comp.d$longitude),]

# Trim outliers in HOOK, following what Simon Hoyle does (SC7-SA-IP-01, Appendix 1)
#comp.d<-comp.d[comp.d$HOOK>200 & comp.d$HOOK<10000,]

# Trim outliers for NHBF, following what Simon Hoyle does (SC7-SA-IP-01, Appendix 1)
#comp.d<-comp.d[(comp.d$NHBF<26 & !is.na(comp.d$NHBF)) | is.na(comp.d$NHBF & comp.d$YY < 1976),]

# remove data for training vessels
#table(comp.d$vessel_type, comp.d$YY, useNA="always")
#comp.d<-comp.d[comp.d$vessel_type==1 | comp.d$vessel_type==4 |(is.na(comp.d$vessel_type)) | (comp.d$vessel_type==2 & comp.d$YY < 1971) ,]
#table(comp.d$vessel_type, comp.d$YY, useNA="always")


# remove some target that were for shark or SWO (per SC7-SA-IP-01 Appendix 1)
# comp.d<-comp.d[(comp.d$gear==3 & !is.na(comp.d$gear)) | is.na(comp.d$gear),]

# # remove callsigns that are not valid; skip this part if you want to keep data prior to late 1970s
# comp.d$CAL<-as.character(comp.d$CAL)
# tmp.flg<-rep(T,length(comp.d$CAL))
# tmp.flg[comp.d$CAL=="XXX   " | comp.d$CAL=="--    " | comp.d$CAL=="      "]<-F
# comp.d<-comp.d[tmp.flg,]
# rm(tmp.flg)

# reformat latitude and longitude ( I think longc=2 is east and longc=1 is west)
# Satoh-san says longitudes of 180 are not correct, so deleting any

rawdat <- comp.d

a <- head(rawdat)
dataprep_JP_EPO2(a)

# Prepare the data
#pd0 <- dataprep_JP_EPO(rawdat)
pd1 <- dataprep_JP_EPO2(rawdat)
pd2 <- setup_EPO_regions(pd1, regBall = TRUE, regBepo = TRUE, regBwcpo = TRUE)

# str(pd1)
# str(pd2)

# # Clean the data
# str(rawdat)
# clndat <- dataclean_JPIO(rawdat)
# prepdat1 <- dataprep_JP(clndat, region = "AO")
# prepdat <- setup_AO_regions(prepdat1, regBpac = T, regBEpac = T) # Later will also need YFT regions, and possibly alternative BET regions
# str(prepdat)
# save(pd1, pd2, prepdat, file = "prepdat.RData")
save(pd1, pd2, file = "prepdat.RData")

#dat <- make_clid(prepdat)
#dat <- make_lbidmon(prepdat)
dat_all <- pd2
clndat <- dataclean_JP_EPO(dat_all, checktg = FALSE)

dat_pac <- clndat
dat_epo <- dat_pac[dat_pac$ocean == 4,]
dat_wcpo <- dat_pac[dat_pac$ocean == 1,]
dat <- dat_epo

save(dat_all, file = "../data/JPdat_all.RData")
save(dat_pac, file = "../data/JPdat_pac.RData")
save(dat_wcpo, file = "../data/JPdat_wcpo.RData")
save(dat_epo, file = "../data/JPdat_epo.RData")
load(file = "../data/JPdat_epo.RData")
dat <- dat_epo

setwd(jpfigs)
rm(prepdat, dat_wcpo, rawdat, comp.d, dat_epo, pd1, pd2, llv, clndat, dat_all)

# ===================================================================================
# Plot and explore the data
# ===================================================================================
# These plots are for checking the data. Not especially important.
table(pd1$op_yr)
table(pd2$op_yr)
table(dat$op_yr)
table(prepdat$op_yr)
table(is.na(pd2$lbid))

xfun <- function(x) sum(x > 0)
a <- table(dat$vessid,dat$op_yr)
apply(a,2,xfun)

# vnm <- (dat$vesselname)
# library("tm")
# tm_map(vnm, function(x) content_transformer(iconv(enc2utf8, sub = "byte")))

# a <- table(dat$vesselname,dat$op_yr)
# apply(a,2,xfun)


# Plot grid squares with sets by region, for each regional structure
a <- unique(paste(dat_all$lat,dat_all$lon))
a0 <- dat_all[match(a,paste(dat_all$lat,dat_all$lon)),c("lat","lon","regBepo","regBall")]
windows(width = 20,height = 14)
for (fld in c("regBepo","regBall")) {
  reg <- with(a0,get(fld))
  plot(a0$lon,a0$lat,type = "n",xlab = "Longitude",ylab = "Latitude",main = fld, xlim = c(120, 290))
  text(a0$lon,a0$lat,labels = reg,cex = 0.6,col = reg + 1)
  maps::map("world2",add = T, fill = TRUE)
  savePlot(paste0("mapf_",fld),type = "png")
}

# Plot effort proportions by yr & region, indicating how much was removed by cleaning
load(paste0(datadir1,"dat_all.RData"))
regBord <- c(1:9,11:15)
windows(height = 12,width = 14); par(mfrow = c(4,4),mar = c(3,2,2,1))
for (r in regBord) {
  xall <- dat_all[dat_all$regBall==r,]
  xpac <- dat_pac[dat_pac$regBall==r,]
  yq <- seq(1952.125,2017.875,0.25)
  aa <- tapply(xall$hooks,xall$yrqtr,sum)
  ap <- tapply(xpac$hooks,xpac$yrqtr,sum)
  yqa <- aa[match(yq,names(aa))]
  yqp <- ap[match(yq,names(ap))]
  yqp[is.na(yqp)] <- 0
  ab <- yqp/yqa
  plot(names(ab),ab,ylim = c(0,1),main = paste("Region",r))
}
savePlot(filename = "Cleaning",type = "png")

# Sets per day and per month
windows(width = 15,height = 9)
hist(dat_all$dmy,breaks = "days",freq = T,xlab = "Date",main = "Sets per day")
savePlot(filename = "sets_per_day.png",type = "png")
hist(dat_all$dmy,breaks = "months",freq = T,xlab = "Date",main = "Sets per month")
savePlot(filename = "sets_per_month.png",type = "png")

windows(width = 15,height = 9)
hist(dat_pac$op_yr,breaks = 1950:2020, main = "Sets per year", xlab = "Year")
savePlot(filename = "sets_per_year.png",type = "png")

# Map of hook distribution, all time
a <- aggregate(dat_all$hooks,list(dat_all$lat5,dat_all$lon5),sum,na.rm = T)
windows(width = 20,height = 15)
symbols(x = a[,2],y = a[,1],circles = .0002*sqrt(a[,3]),inches = F,bg = 2,fg = 2,xlab = "Longitude",ylab = "Latitude",ylim = c(-50, 50), xlim = c(120, 290))
maps::map("world2",add = T,interior = F,fill = T)
savePlot(filename = "map_hooks.png",type = "png")

# Histogram of hooks per set
hist(dat$hooks, nclass = 60,xlab = "Hooks per set")   # ask if very large # hooks is okay
savePlot("Hook histogram.png",type = "png")
table(dat$hooks[dat$hooks > 5000])

# Check catch distribtions for outliers. Probably no need to remove.
str(dat)
str(dat1)
table(dat_all$alb)
table(dat_all$bet)
table(dat_all$yft)
#table(dat_all$ott)
table(dat_all$swo)
table(dat_all$mls)
table(dat_all$bum)
table(dat_all$blm)
#table(dat_all$otb)
#table(dat_all$skj)
#table(dat_all$sha)   # ask majority of sets (=719211) with 0 sha. Also one set with 663
#table(dat_all$oth)   # ask sets with 3059! But most (=636641) have 0.
table(dat_all$hbf,useNA = "always")  # 6408 with NA! All in 1973-75

table(comp.d$NHBF,comp.d$YY,useNA = "always")
table(dat_all$hbf,dat_all$op_yr,useNA = "always")
table(cut(dat$hbf,c(0,1,2,3,4,5,6,8,10,15,20,25,30)),dat$op_yr,useNA = "always")  #
table(cut(comp.d$NHBF,c(0,1,2,3,4,5,6,8,10,15,20,25,30)),comp.d$YY,useNA = "always")  #
table(dat$op_yr,is.na(dat$hbf))  #

# Store some results (aggregated to avoid data concerns) for later reporting.
#dat <- dat[is.na(dat$hbf) == FALSE | dat$op_yr < 1976,]
a <- table(dat$op_yr,round(dat$hbf,0),useNA = "always")
write.csv(a,"table hbf by year.csv")

table(clndat$lonc) # all good

# Set density map by 5 degree cell
a <- log(table(dat_pac$lon5,dat_pac$lat5))
windows(width = 13,height = 10)
image(as.numeric(dimnames(a)[[1]]),as.numeric(dimnames(a)[[2]]),a,xlab = "Longitude",ylab = "Latitude",ylim = c(-60,60),xlim = c(100,300))
maps::map("world2",add = T, interior = F,fill = TRUE)
savePlot("Setmap_logscale.png",type = "png")

# Set density map by 1 degree cell
a <- with(dat_pac,log(table(lon,lat)))
windows(width = 13,height = 10)
image(as.numeric(dimnames(a)[[1]])+.5,as.numeric(dimnames(a)[[2]])+.5,a,xlab = "Longitude",ylab = "Latitude",ylim = c(-60,60),xlim = c(100,300))
maps::map("world2",add = T, interior = F,fill = TRUE)
savePlot("Setmap_logscale_1deg.png",type = "png")

windows(width = 13,height = 10)
image(as.numeric(dimnames(a)[[1]])+.5,as.numeric(dimnames(a)[[2]])+.5,a,xlab = "Longitude",ylab = "Latitude",ylim = c(-60,60),xlim = c(100,300),xaxt="n")
map_EPO()
savePlot("regbet.png",type = "png")

# Mean fishing location  by yearqtr
windows(width = 15,height = 10);par(mfrow = c(1,2), oma = c(0,0,2,0))
ax <- tapply(dat$yrqtr,dat$yrqtr,mean); ay = tapply(dat$lat5,dat$yrqtr,mean)
plot(ax,ay,xlab = "yr",ylab = "Mean latitude",type = "n")
a <- 4*(.125+dat$yrqtr-floor(dat$yrqtr))
a <- tapply(a,dat$yrqtr,mean)
text(ax,ay,a,cex = 0.7)
ax = tapply(dat$lon5,dat$yrqtr,mean);ay = tapply(dat$yrqtr,dat$yrqtr,mean)
plot(ax,ay,ylab = "yr",xlab = "Mean longitude",type = "n")
text(ax,ay,a,cex = 0.7)
mtext("EPO", outer = TRUE, font = 2)
savePlot("mean_fishing_location1 epo.png",type = "png")

windows(width = 15,height = 10);par(mfrow = c(1,2), oma = c(0,0,2,0))
ax <- tapply(dat_pac$yrqtr,dat_pac$yrqtr,mean); ay = tapply(dat_pac$lat5,dat_pac$yrqtr,mean)
plot(ax,ay,xlab = "yr",ylab = "Mean latitude",type = "n")
a <- 4*(.125+dat_pac$yrqtr-floor(dat_pac$yrqtr))
a <- tapply(a,dat_pac$yrqtr,mean)
text(ax,ay,a,cex = 0.7)
ax = tapply(dat_pac$lon5,dat_pac$yrqtr,mean);ay = tapply(dat_pac$yrqtr,dat_pac$yrqtr,mean)
plot(ax,ay,ylab = "yr",xlab = "Mean longitude",type = "n")
text(ax,ay,a,cex = 0.7)
mtext("Pacific", outer = TRUE, font = 2)
savePlot("mean_fishing_location1 pacific.png",type = "png")

write.csv(table(round(dat$hbf,0),dat$regBall,useNA = "always"),file = "hbf by region.csv")
write.csv(table(round(dat$hbf,0),floor(dat$yrqtr/5)*5,dat$regBall,useNA = "always"),file = "hbf by region by 5 years.csv")

# Plot hbf. Change spatial selection criteria for AO.
windows(20,14);par(mfrow = c(3,3),mar = c(2,2,2,2))
for (y in seq(1975,2015,5)) {
  a <- dat[floor(dat$yrqtr/5)*5==y & dat$lon5 < 125 & dat$lat5 < 55,]
  a <- tapply(a$hbf,list(a$lon5,a$lat5),mean,na.rm = T)
  image(as.numeric(dimnames(a)[[1]]),as.numeric(dimnames(a)[[2]]),a,main = y,zlim = c(6,24),col = heat.colors(30),xlab = "Lon",ylab = "Lat",ylim = c(-50,50))
  contour(as.numeric(dimnames(a)[[1]]),as.numeric(dimnames(a)[[2]]),a,add = T,levels = seq(0,26,2))
  map("world",add = T, interior = F,fill = T)
  }
savePlot("mean_HBF.png",type = "png")
qqs <- c(0.125,0.375,0.625,0.875)
for (qq in 1:4) {
  windows(20,14);par(mfrow = c(3,3),mar = c(2,2,2,2),oma = c(0,0,1,0))
  for (y in seq(1975,2015,5)) {
    a <- dat[dat$yrqtr %in% (qqs[qq]+y:(y+4)) & dat$lon5 < 125 & dat$lat5 < 55,]
    a <- tapply(a$hbf,list(a$lon5,a$lat5),mean,na.rm = T)
    image(as.numeric(dimnames(a)[[1]]),as.numeric(dimnames(a)[[2]]),a,main = y,zlim = c(6,24),col = heat.colors(30),xlab = "Lon",ylab = "Lat",xlim = c(-100,20),ylim = c(-55,55))
    contour(as.numeric(dimnames(a)[[1]]),as.numeric(dimnames(a)[[2]]),a,add = T,levels = seq(0,26,2))
    map("world",add = T, interior = F,fill = T)
    }
  title(paste("Quarter",qq),outer = T,line = 0)
  savePlot(paste0("mean_HBF_q",qq,".png"),type = "png")
  }

#write.csv(table(dat$ncrew,dat$reg),file = "crew by region.csv")
#write.csv(table(dat$ncrew,floor(dat$yrqtr/10)*10),file = "crew by decade.csv")
#write.csv(table(dat$ncrew,dat$fishingcat,useNA = "ifany"),file = "crew by fishingcat.csv")
write.csv(table(dat$lat5,dat$lon5),file = "ops by lat-long.csv")
write.csv(table(dat$lat5,dat$lon5,5*floor(dat$yrqtr/5)),file = "ops by lat-long-5yr.csv")

# data exploration
#install.packages("rpart")
library("rpart")
a <- dat[dat$regBall %in% c(2),]
dim(a)
a$betcpue <- a$bet/a$hooks
a$albcpue <- a$alb/a$hooks
a$yftcpue <- a$yft/a$hooks
a$sbtcpue <- a$sbt/a$hooks
a$swocpue <- a$swo/a$hooks
a$bftcpue <- a$bft/a$hooks
a$mlscpue <- a$mls/a$hooks
a$blmcpue <- a$blm/a$hooks
a$bumcpue <- a$bum/a$hooks
#simplemod <- rpart(a$betcpue ~ a$lon + a$lat + a$yrqtr + a$swocpue + a$albcpue + a$othcpue + a$mlscpue + a$blmcpue + a$bumcpue)
simplemod <- rpart(a$betcpue ~ a$lon + a$lat + a$yrqtr + a$swocpue + a$albcpue + a$yftcpue + a$mlscpue + a$blmcpue + a$bumcpue)
windows(width = 11,height = 7)
plot(simplemod)
text(simplemod)
savePlot("Rpart bet cpue",type = "png")
simplemod <- rpart(a$yftcpue ~ a$lon + a$lat + a$yrqtr + a$swocpue + a$albcpue + a$betcpue + a$mlscpue + a$blmcpue + a$bumcpue)
windows(width = 11,height = 7)
plot(simplemod)
text(simplemod)
savePlot("Rpart yft cpue",type = "png")

library("randomForest") # These take a long time and use a lot of memory, but are useful.
simplefor <- randomForest(a$betcpue ~ a$lon + a$lat + a$yrqtr + a$swocpue + a$bftcpue + a$albcpue + a$yftcpue + a$mlscpue + a$blmcpue + a$bumcpue)
print(simplefor)
windows(width = 11,height = 7)
plot(importance)
text(varImpPlot,main = NULL)
savePlot("Rforest bet cpue",type = "png")
simplefor <- randomForest(a$yftcpue ~ a$lon + a$lat + a$yrqtr + a$swocpue + a$albcpue + a$betcpue + a$mlscpue + a$blmcpue + a$bumcpue)
print(simplefor)
windows(width = 11,height = 7)
plot(importance)
text(varImpPlot,main = NULL)
savePlot("Rforest yft cpue",type = "png")


a <- with(dat[dat$regBepo==1,],table(set_target, op_yr, exclude=NULL))
b <- apply(a,2,sum)
a
b
t(a)/b

# ===================================================================================
# Start the analysis proper
# ===================================================================================
#Clustering

library("date")
library("splines")
library("maps")
library("mapdata")
library("maptools")
library("lunar")
library("mgcv")
library("randomForest")
library("influ")
library("nFactors")
library("plyr")
library("dplyr")
library("data.table")
library("boot")
library("beanplot")
library("cpue.rfmo")
library("fastcluster")

projdir <- "~/IATTC/2019_CPUE/"
jpdir <- paste0(projdir, "JP/")
datadir1 <- paste0(jpdir, "data/")
jalysis_dir <- paste0(jpdir, "analyses/")
Rdir <- paste0(projdir, "Rfiles/")
clusdir <- paste0(jpdir, "clustering/")
#clusdir_xsoi <- paste0(jpdir, "clustering_xsoi/")
dir.create(clusdir)
setwd(clusdir)

load(file = "../data/JPdat_epo.RData")
dat <- dat_epo


table(dat$mls > 0, dat$op_yr)

load(paste0(datadir1,"JPdat_wcpo.RData"))
table(dat_wcpo$mls > 0, dat_wcpo$op_yr)
rm(dat_wcpo)

a <- aggregate(hooks ~ tripidmon + op_yr, data = dat, length)
table(a$op_yr)
tapply(a$hooks, a$op_yr, mean)
b <- tapply(a$hooks, a$op_yr, mean)
plot(as.numeric(names(b)), b, ylim = c(0, 25), xlab = "Year", ylab = "Sets per month per vessel")

a <- aggregate(hooks ~ tripidwk + op_yr, data = dat, length)
table(a$op_yr)
tapply(a$hooks, a$op_yr, mean)

a <- aggregate(hooks ~ lbid_mon + op_yr, data = dat, length)
table(a$op_yr)
tapply(a$hooks, a$op_yr, mean)
b <- tapply(a$hooks, a$op_yr, mean)
windows()
plot(as.numeric(names(b)), b, ylim = c(0, 25), xlab = "Year", ylab = "Sets per vessel per month")
savePlot("Sets per vessel per month", type = "png")

a <- aggregate(hooks ~ lbid_wk + op_yr, data = dat, length)
table(a$op_yr)
tapply(a$hooks, a$op_yr, mean)


# Remove redundant datasets, if present. Don't worry if not.
rm(prepdat,prepdat1,pd1,pd2,clndat,rawdat,dataset,llv)

gc()
jp_splist <- c("alb","bet","yft","swo","mls","bum","blm","sas","sha","sfa","ssp")
dat <- data.frame(dat)
flag = "JP"

tdat <- dat[dat$op_day==1,]
str(tdat)
a <- table(dat$vessid, dat$regBepo)

for (r in c(1:4)) {
  windows(15,12); par(mfrow = c(4,3), mar = c(3,2,2,1), oma = c(0,0,2,0))
  a <- dat[dat$regBepo == r,]
  for (sp in jp_splist) plot(sort(unique(a$yrqtr)),tapply(a[,sp], a$yrqtr, mean), main = sp)
  title(paste("Region", r ), outer = TRUE)
  savePlot(filename = paste("freq",flag,"Region", r, sep = "_"), type = "png")
}

a <- as.data.frame(group_by(dat, lbid_mon, regBepo) %>% summarise(length = length(vessid)))
head(a)
a <- a[a$regBepo==1,]
a <- a[a$length > 3,]
tdat <- dat[dat$lbid_mon %in% a$lbid_mon | dat$regBepo != 1,]
dim(dat); dim(tdat)

hist(a[a > 0], nclass=60)

use_splist <- c("alb","bet","yft","swo","mls","bum","sas")
allabs <- c("vessid","yrqtr","latlong","op_yr","op_mon","hbf","hooks","tripidmon","tripidwk","lbid_mon","lbid_wk", "moon",use_splist,"Total","dmy","lat","lon","lat5","lon5","regBepo")
str(dat[,allabs])
allabs[!allabs %in% names(dat)]
tdat <- tdat[tdat$op_yr > 1975,]
str(dat)

nclB = c(3,4,4,4) # Number of bigeye clusters. Will need to be adjusted for each fleet.
cvn <- c("yrqtr","latlong","hooks","hbf","vessid","Total","lat","lon","lat5","lon5","moon","op_yr","op_mon","regBepo")
r = 4


regtype = "regBepo"
for (r in 1:length(nclB)) {
  fnh <- paste(flag,regtype,r,sep = "_")
  dataset <- clust_PCA_run(r = r,ddd = tdat,allsp = use_splist,allabs = allabs,regtype = regtype,ncl = nclB[r],plotPCA = F,clustid = "lbid_mon",allclust = F,flag = flag,fnhead = fnh,covarnames = cvn)
  save(dataset,file = paste0(fnh,".RData"))
}

# ========= as an exercise, run clustering without the species of interest ===========
clusdir_xsoi <- paste0(jpdir, "clustering_xsoi/")
dir.create(clusdir_xsoi)
setwd(clusdir_xsoi)
setwd(clusdir)
load(file = paste0(jalysis_dir,"JPdat.RData"))

gc()
jp_splist <- c("alb","bet","yft","swo","mls","bum","blm","bft","sbt","sas","sha")
use_splist <- c("alb","yft","swo","mls","bum","bft","sbt","sas")
allabs <- c("vessid","yrqtr","latlong","op_yr","op_mon","hbf","hooks","tripid","tripidmon","lbid_mon","moon",use_splist,"Total","dmy","lat","lon","lat5","lon5","regBepo","regBall","bet")
dat <- data.frame(dat)
str(dat[,allabs])
flag = "JP"

nclB = c(4,4,4) # Number of bigeye clusters. Will need to be adjusted for each fleet.
cvn <- c("yrqtr","latlong","hooks","hbf","vessid","Total","lat","lon","lat5","lon5","moon","op_yr","op_mon","regBepo","regBall","bet")
r = 3


regtype = "regBepo"
for (r in 1:length(nclB)) {
  fnh <- paste(flag,regtype,r,sep = "_")
  dataset <- clust_PCA_run(r = r,ddd = dat,allsp = use_splist,allabs = allabs,regtype = regtype,ncl = nclB[r],plotPCA = F,clustid = "lbid_mon",allclust = F,flag = flag,fnhead = fnh,covarnames = cvn)
  save(dataset,file = paste0(fnh,".RData"))
}

getwd()


##################################################
# Japan only, no clusters, HBF
#
# R1 - 4 clusters, 1=bet, 2=alb+bet, 3=bft, 4=yft+bet+mls+bft+alb. Use 1,2,4.
# R2 - 4 or 2 clusters. 1=bet+yft+swo, 2=bet, 3=yft+bet, 4=alb+bet+yft. Use 1,2,3,4.
# R3 - 4 or 3 clusters. 1=bet, 2=alb+bet, 3=bet+yft, 4=alb+mls+bum+sas. Use 1,2,3.

library("date")
library("splines")
library("maps")
library("mapdata")
library("maptools")
library("lunar")
library("mgcv")
library("randomForest")
library("influ")
library("nFactors")
library("plyr")
library("dplyr")
library("data.table")
library("cluster")
library("beanplot")
library("cpue.rfmo")

projdir <- "~/IATTC/2019_CPUE/"
jpdir <- paste0(projdir, "JP/")
datadir1 <- paste0(jpdir, "data/")
jalysis_dir <- paste0(jpdir, "analyses/")
Rdir <- paste0(projdir, "Rfiles/")

resdir <- paste0(jalysis_dir,"std_cl_JPonly_nohbf/")
dir.create(resdir)
setwd(resdir)

#clkeepCN_B <- list("bet" = list(c(1,2,3,4),c(1,2,3,4),c(1,2,3,4)))
clkeepJP_B <- list("bet" = list(c(1,2,4),c(1,2,3,4),c(1,2,3)))
clkeepKR_B <- list("bet" = list(c(0),c(1,2,3,4),c(1,2,3)))
clkeepTW_B <- list("bet" = list(c(4),c(2,3),c(0)))
clkeepUS_B <- list("bet" = list(c(2,3),c(1,3),c(0)))
clk_B <- list(JP = clkeepJP_B,KR = clkeepKR_B,TW = clkeepTW_B,US = clkeepUS_B)

flag <- "JP"
runpars <- list()
runpars[["bet"]] <- list(regtype = "regBEpac", regtype2 = "B", clk = clk_B, doregs = 1:3, addcl = TRUE, dohbf = FALSE, cltype = "hcltrp")
use_splist <- c("alb","bet","yft")
stdlabs <- c("vessid","yrqtr","latlong","op_yr","op_mon","hbf","hooks","moon",use_splist,"Total","lat","lon","lat5","lon5","hcltrp","reg","flag")

runreg = 1; runsp = "bet"
keepd = TRUE; maxyr = 2018; maxqtrs = 200; minqtrs_byreg = c(5,5,5);
for (runsp in c("bet")) {
  regtype <- runpars[[runsp]]$regtype
  clk <- runpars[[runsp]]$clk
  addcl <- runpars[[runsp]]$addcl
  dohbf <- runpars[[runsp]]$dohbf
  cltype <- runpars[[runsp]]$cltype
  jdat <- data.frame()
  for (flag in c("JP")) {
    for (r in runpars[[runsp]]$doregs) {
      load(paste0(projdir,flag,"/clustering/",paste(flag,regtype,r,sep = "_"),".RData"))
      dataset$flag <- flag
      jdat <- rbind(jdat,dataset[,stdlabs])
      rm(dataset)
    }
  }
  jdat <- jdat[jdat$yrqtr < maxyr,]
  jdat$vessidx <- jdat$vessid
  jdat$vessid <- paste0(jdat$flag,jdat$vessid)
  jdat$vessid <- as.factor(jdat$vessid)
  jdat <- jdat[jdat$yrqtr > 2005 | jdat$flag != "TW",]

  vars <- c("vessid","hooks","yrqtr","latlong","hbf")
  for (runreg in runpars[[runsp]]$doregs) {
      minqtrs <- minqtrs_byreg[runreg]
      glmdat <- select_data_JointIO(jdat,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars, maxqtrs = maxqtrs,
                                    minvess = 50, minll = 50, minyrqtr = 50, addcl = addcl, cltype = cltype, addpca = NA, samp = NA, strsmp = NA)
      if (nrow(glmdat) > 60000) glmdat <- samp_strat_data(glmdat,60)
      glmdat5279 <- select_data_JointIO(jdat,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars,maxqtrs = maxqtrs,
                                        minvess = 50,minll = 50,minyrqtr = 50,addcl = addcl,cltype = cltype,addpca = NA,samp = NA,strsmp = NA,
                                        yrlims = c(1952,1980))
      if (nrow(glmdat5279) > 60000) glmdat5279 <- samp_strat_data(glmdat5279,60)
      a <- jdat[jdat$vessid != "JP1",]
      glmdat79nd <- select_data_JointIO(a,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars,maxqtrs = maxqtrs,
                                        minvess = 50,minll = 50,minyrqtr = 50,addcl = addcl,cltype = cltype,addpca = NA,samp = NA,strsmp = NA,
                                        yrlims = c(1979,maxyr))
      if (nrow(glmdat79nd) > 60000) glmdat79nd <- samp_strat_data(glmdat79nd,60)
      wtt.all   <- mk_wts(glmdat,wttype = "area")
      wtt.5279   <- mk_wts(glmdat5279,wttype = "area")
      wtt.79nd   <- mk_wts(glmdat79nd,wttype = "area")
      fmla.oplogn <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = F,addcl = T,nhbf = 3)
      fmla.oplogn_ncl <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = F,addcl = F,nhbf = 3)
      fmla.boatlogn <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = T,addcl = T,nhbf = 3)
      fmla.boatlogn_ncl <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = T,addcl = F,nhbf = 3)
      mn <- with(glmdat,0.1* mean(get(runsp)/hooks))

      modlab = "lognC_novess_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
      if (lu(glmdat$clust) > 1)
      { model <- glm(fmla.oplogn,data = glmdat,weights = wtt.all,family = "gaussian");gc() } else
      { model <- glm(fmla.oplogn_ncl,data = glmdat,weights = wtt.all,family = "gaussian");gc() }
      summarize_and_store(mod = model,dat = glmdat,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

      modlab = "lognC_boat_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
      if (lu(glmdat$clust) > 1)
      { model <- glm(fmla.boatlogn,data = glmdat,weights = wtt.all,family = "gaussian");gc() } else
      { model <- glm(fmla.boatlogn_ncl,data = glmdat,weights = wtt.all,family = "gaussian");gc() }
      summarize_and_store(mod = model,dat = glmdat,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

      modlab = "lognC_novess_5279"; fname <- paste0("Joint_",regtype,"_R",runreg)
      mn <- with(glmdat5279,0.1* mean(get(runsp)/hooks))
      if (lu(glmdat5279$clust) > 1)
      { model <- glm(fmla.oplogn,data = glmdat5279,weights = wtt.5279,family = "gaussian");gc() } else
      { model <- glm(fmla.oplogn_ncl,data = glmdat5279,weights = wtt.5279,family = "gaussian");gc() }
      summarize_and_store(mod = model,dat = glmdat5279,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

      modlab = "lognC_vessid_79nd"; fname <- paste0("Joint_",regtype,"_R",runreg)
      mn <- with(glmdat79nd,0.1* mean(get(runsp)/hooks))
      if (lu(glmdat79nd$clust) > 1)
      { model <- glm(fmla.boatlogn,    data = glmdat79nd,weights = wtt.79nd,family = "gaussian");gc() } else
      { model <- glm(fmla.boatlogn_ncl,data = glmdat79nd,weights = wtt.79nd,family = "gaussian");gc() }
      summarize_and_store(mod = model,dat = glmdat79nd,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

      # delta lognormal
      modlab = "dellog_novess_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg);
      do_deltalog(dat = glmdat,dohbf = dohbf,addboat = F,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

      modlab = "dellog_boat_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
      do_deltalog(dat = glmdat,dohbf = dohbf,addboat = T,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

      modlab = "dellog_novess_5279"; fname <- paste0("Joint_",regtype,"_R",runreg)
      do_deltalog(dat = glmdat5279,dohbf = dohbf,addboat = F,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

      modlab = "dellog_vessid_79nd"; fname <- paste0("Joint_",regtype,"_R",runreg)
      do_deltalog(dat = glmdat79nd,dohbf = dohbf,addboat = T,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

      graphics.off()
    }
}

#####-----------------------------------

resdir <- paste0(jalysis_dir,"std_cl_JPonly_hbf/")
dir.create(resdir)
setwd(resdir)

flag <- "JP"
runpars <- list()
runpars[["bet"]] <- list(regtype = "regBpac", regtype2 = "B", clk = clk_B, doregs = 1:3, addcl = TRUE, dohbf = TRUE, cltype = "hcltrp")
use_splist <- c("alb","bet","yft")
stdlabs <- c("vessid","yrqtr","latlong","op_yr","op_mon","hbf","hooks","moon",use_splist,"Total","lat","lon","lat5","lon5","hcltrp","reg","flag")

runreg = 1; runsp = "bet"
keepd = TRUE; maxyr = 2018; maxqtrs = 200; minqtrs_byreg = c(5,5,5);
for (runsp in c("bet")) {
  regtype <- runpars[[runsp]]$regtype
  clk <- runpars[[runsp]]$clk
  addcl <- runpars[[runsp]]$addcl
  dohbf <- runpars[[runsp]]$dohbf
  cltype <- runpars[[runsp]]$cltype
  jdat <- data.frame()
  for (flag in c("JP")) {
    for (r in runpars[[runsp]]$doregs) {
      load(paste0(projdir,flag,"/clustering/",paste(flag,regtype,r,sep = "_"),".RData"))
      dataset$flag <- flag
      jdat <- rbind(jdat,dataset[,stdlabs])
      rm(dataset)
    }
  }
  jdat <- jdat[jdat$yrqtr < maxyr,]
  jdat$vessidx <- jdat$vessid
  jdat$vessid <- paste0(jdat$flag,jdat$vessid)
  jdat$vessid <- as.factor(jdat$vessid)
  jdat <- jdat[jdat$yrqtr > 2005 | jdat$flag != "TW",]

  vars <- c("vessid","hooks","yrqtr","latlong","hbf")
  for (runreg in runpars[[runsp]]$doregs) {
    minqtrs <- minqtrs_byreg[runreg]
    glmdat <- select_data_JointIO(jdat,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars, maxqtrs = maxqtrs, minvess = 50, minll = 50, minyrqtr = 50, addcl = addcl, cltype = cltype, addpca = NA, samp = NA, strsmp = NA)
    if (nrow(glmdat) > 60000) glmdat <- samp_strat_data(glmdat,60)
    glmdat5279 <- select_data_JointIO(jdat,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars,maxqtrs = maxqtrs, minvess = 50,minll = 50,minyrqtr = 50,addcl = addcl,cltype = cltype,addpca = NA,samp = NA,strsmp = NA,yrlims = c(1952,1980))
    if (nrow(glmdat5279) > 60000) glmdat5279 <- samp_strat_data(glmdat5279,60)
    a <- jdat[jdat$vessid != "JP1",]
    glmdat79nd <- select_data_JointIO(a,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars,maxqtrs = maxqtrs, minvess = 50,minll = 50,minyrqtr = 50,addcl = addcl,cltype = cltype,addpca = NA,samp = NA,strsmp = NA,yrlims = c(1979,maxyr))
    if (nrow(glmdat79nd) > 60000) glmdat79nd <- samp_strat_data(glmdat79nd,60)
    wtt.all   <- mk_wts(glmdat,wttype = "area")
    wtt.5279   <- mk_wts(glmdat5279,wttype = "area")
    wtt.79nd   <- mk_wts(glmdat79nd,wttype = "area")
    fmla.oplogn <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = F,addcl = T,nhbf = 3)
    fmla.oplogn_ncl <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = F,addcl = F,nhbf = 3)
    fmla.boatlogn <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = T,addcl = T,nhbf = 3)
    fmla.boatlogn_ncl <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = T,addcl = F,nhbf = 3)
    mn <- with(glmdat,0.1* mean(get(runsp)/hooks))

    modlab = "lognC_novess_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
    if (lu(glmdat$clust) > 1)
    { model <- glm(fmla.oplogn,data = glmdat,weights = wtt.all,family = "gaussian");gc() } else
    { model <- glm(fmla.oplogn_ncl,data = glmdat,weights = wtt.all,family = "gaussian");gc() }
    summarize_and_store(mod = model,dat = glmdat,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

    modlab = "lognC_boat_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
    if (lu(glmdat$clust) > 1)
    { model <- glm(fmla.boatlogn,data = glmdat,weights = wtt.all,family = "gaussian");gc() } else
    { model <- glm(fmla.boatlogn_ncl,data = glmdat,weights = wtt.all,family = "gaussian");gc() }
    summarize_and_store(mod = model,dat = glmdat,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

    modlab = "lognC_novess_5279"; fname <- paste0("Joint_",regtype,"_R",runreg)
    mn <- with(glmdat5279,0.1* mean(get(runsp)/hooks))
    if (lu(glmdat5279$clust) > 1)
    { model <- glm(fmla.oplogn,data = glmdat5279,weights = wtt.5279,family = "gaussian");gc() } else
    { model <- glm(fmla.oplogn_ncl,data = glmdat5279,weights = wtt.5279,family = "gaussian");gc() }
    summarize_and_store(mod = model,dat = glmdat5279,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

    modlab = "lognC_vessid_79nd"; fname <- paste0("Joint_",regtype,"_R",runreg)
    mn <- with(glmdat79nd,0.1* mean(get(runsp)/hooks))
    if (lu(glmdat79nd$clust) > 1)
    { model <- glm(fmla.boatlogn,    data = glmdat79nd,weights = wtt.79nd,family = "gaussian");gc() } else
    { model <- glm(fmla.boatlogn_ncl,data = glmdat79nd,weights = wtt.79nd,family = "gaussian");gc() }
    summarize_and_store(mod = model,dat = glmdat79nd,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

#    delta lognormal
    modlab = "dellog_novess_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg);
    do_deltalog(dat = glmdat,dohbf = dohbf,addboat = F,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

    modlab = "dellog_boat_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
    do_deltalog(dat = glmdat,dohbf = dohbf,addboat = T,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

    modlab = "dellog_novess_5279"; fname <- paste0("Joint_",regtype,"_R",runreg)
    do_deltalog(dat = glmdat5279,dohbf = dohbf,addboat = F,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

    modlab = "dellog_vessid_79nd"; fname <- paste0("Joint_",regtype,"_R",runreg)
    do_deltalog(dat = glmdat79nd,dohbf = dohbf,addboat = T,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

    graphics.off()
  }
}


##############################
# clustring_xsoi

resdir <- paste0(jalysis_dir,"std_cl_JPonly_xsoi/")
dir.create(resdir)
setwd(resdir)

flag <- "JP"
runpars <- list()
runpars[["bet"]] <- list(regtype = "regBpac", regtype2 = "B", clk = clk_B, doregs = 1:3, addcl = TRUE, dohbf = TRUE, cltype = "hcltrp")
use_splist <- c("alb","bet","yft")
stdlabs <- c("vessid","yrqtr","latlong","op_yr","op_mon","hbf","hooks","moon",use_splist,"Total","lat","lon","lat5","lon5","hcltrp","reg","flag")

runreg = 1; runsp = "bet"
keepd = TRUE; maxyr = 2018; maxqtrs = 200; minqtrs_byreg = c(5,5,5);
for (runsp in c("bet")) {
  regtype <- runpars[[runsp]]$regtype
  clk <- runpars[[runsp]]$clk
  addcl <- runpars[[runsp]]$addcl
  dohbf <- runpars[[runsp]]$dohbf
  cltype <- runpars[[runsp]]$cltype
  jdat <- data.frame()
  for (flag in c("JP")) {
    for (r in runpars[[runsp]]$doregs) {
      load(paste0(projdir,flag,"/clustering_xsoi/",paste(flag,regtype,r,sep = "_"),".RData"))
      dataset$flag <- flag
      jdat <- rbind(jdat,dataset[,stdlabs])
      rm(dataset)
    }
  }
  jdat <- jdat[jdat$yrqtr < maxyr,]
  jdat$vessidx <- jdat$vessid
  jdat$vessid <- paste0(jdat$flag,jdat$vessid)
  jdat$vessid <- as.factor(jdat$vessid)
  jdat <- jdat[jdat$yrqtr > 2005 | jdat$flag != "TW",]

  vars <- c("vessid","hooks","yrqtr","latlong","hbf")
  for (runreg in runpars[[runsp]]$doregs) {
    minqtrs <- minqtrs_byreg[runreg]
    glmdat <- select_data_JointIO(jdat,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars, maxqtrs = maxqtrs, minvess = 50, minll = 50, minyrqtr = 50, addcl = addcl, cltype = cltype, addpca = NA, samp = NA, strsmp = NA)
    if (nrow(glmdat) > 60000) glmdat <- samp_strat_data(glmdat,60)
    glmdat5279 <- select_data_JointIO(jdat,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars,maxqtrs = maxqtrs, minvess = 50,minll = 50,minyrqtr = 50,addcl = addcl,cltype = cltype,addpca = NA,samp = NA,strsmp = NA,yrlims = c(1952,1980))
    if (nrow(glmdat5279) > 60000) glmdat5279 <- samp_strat_data(glmdat5279,60)
    a <- jdat[jdat$vessid != "JP1",]
    glmdat79nd <- select_data_JointIO(a,runreg = runreg,clk = clk,minqtrs = minqtrs,runsp = runsp,mt = "deltabin",vars = vars,maxqtrs = maxqtrs, minvess = 50,minll = 50,minyrqtr = 50,addcl = addcl,cltype = cltype,addpca = NA,samp = NA,strsmp = NA,yrlims = c(1979,maxyr))
    if (nrow(glmdat79nd) > 60000) glmdat79nd <- samp_strat_data(glmdat79nd,60)
    wtt.all   <- mk_wts(glmdat,wttype = "area")
    wtt.5279   <- mk_wts(glmdat5279,wttype = "area")
    wtt.79nd   <- mk_wts(glmdat79nd,wttype = "area")
    fmla.oplogn <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = F,addcl = T,nhbf = 3)
    fmla.oplogn_ncl <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = F,addcl = F,nhbf = 3)
    fmla.boatlogn <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = T,addcl = T,nhbf = 3)
    fmla.boatlogn_ncl <- make_formula_IO(runsp,modtype = "logn",dohbf = dohbf,addboat = T,addcl = F,nhbf = 3)
    mn <- with(glmdat,0.1* mean(get(runsp)/hooks))

    modlab = "lognC_novess_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
    if (lu(glmdat$clust) > 1)
    { model <- glm(fmla.oplogn,data = glmdat,weights = wtt.all,family = "gaussian");gc() } else
    { model <- glm(fmla.oplogn_ncl,data = glmdat,weights = wtt.all,family = "gaussian");gc() }
    summarize_and_store(mod = model,dat = glmdat,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

    modlab = "lognC_boat_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
    if (lu(glmdat$clust) > 1)
    { model <- glm(fmla.boatlogn,data = glmdat,weights = wtt.all,family = "gaussian");gc() } else
    { model <- glm(fmla.boatlogn_ncl,data = glmdat,weights = wtt.all,family = "gaussian");gc() }
    summarize_and_store(mod = model,dat = glmdat,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

    modlab = "lognC_novess_5279"; fname <- paste0("Joint_",regtype,"_R",runreg)
    mn <- with(glmdat5279,0.1* mean(get(runsp)/hooks))
    if (lu(glmdat5279$clust) > 1)
    { model <- glm(fmla.oplogn,data = glmdat5279,weights = wtt.5279,family = "gaussian");gc() } else
    { model <- glm(fmla.oplogn_ncl,data = glmdat5279,weights = wtt.5279,family = "gaussian");gc() }
    summarize_and_store(mod = model,dat = glmdat5279,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

    modlab = "lognC_vessid_79nd"; fname <- paste0("Joint_",regtype,"_R",runreg)
    mn <- with(glmdat79nd,0.1* mean(get(runsp)/hooks))
    if (lu(glmdat79nd$clust) > 1)
    { model <- glm(fmla.boatlogn,    data = glmdat79nd,weights = wtt.79nd,family = "gaussian");gc() } else
    { model <- glm(fmla.boatlogn_ncl,data = glmdat79nd,weights = wtt.79nd,family = "gaussian");gc() }
    summarize_and_store(mod = model,dat = glmdat79nd,fname,modlab,dohbf = dohbf, keepd = keepd);rm(model)

    #    delta lognormal
    modlab = "dellog_novess_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg);
    do_deltalog(dat = glmdat,dohbf = dohbf,addboat = F,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

    modlab = "dellog_boat_allyrs"; fname <- paste0("Joint_",regtype,"_R",runreg)
    do_deltalog(dat = glmdat,dohbf = dohbf,addboat = T,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

    modlab = "dellog_novess_5279"; fname <- paste0("Joint_",regtype,"_R",runreg)
    do_deltalog(dat = glmdat5279,dohbf = dohbf,addboat = F,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

    modlab = "dellog_vessid_79nd"; fname <- paste0("Joint_",regtype,"_R",runreg)
    do_deltalog(dat = glmdat79nd,dohbf = dohbf,addboat = T,addcl = addcl,nhbf = 3,runsp = runsp,fname = fname,modlab = modlab, keepd = keepd)

    graphics.off()
  }
}

